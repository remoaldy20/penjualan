<?php
use Illuminate\Database\Seeder;
use App\Kategori;

class KategoriTableSeeder extends Seeder
{
 /**
 * Run the database seeds.
 *
 * @return void
 */
 public function run()
 {
        Kategori::create([
            'nama' => 'Makanan'
        ]);
        Kategori::create([
            'nama' => 'Perlengkapan Rumah Tangga'
        ]);
        Kategori::create([
            'nama' => 'Alat Belajar'
        ]);

        
    }
}
